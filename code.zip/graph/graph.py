import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib import style
from struct import *
import serial

ser=serial.Serial(port='COM5', baudrate = 115200, bytesize=8, timeout= None)
#style.use('fivethirtyeight')
style.use('ggplot')

fig = plt.figure()
fig.set_size_inches(11,6)
ax1 = fig.add_subplot(1,1,1)
#ax2 = fig.add_subplot(2,1,2)

x_ax = [] #time
y1_ax = [] #amplitude
y2_ax = []

def animate(i):
    graph_data = ser.read(720)#30 sets data
    y=unpack('dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd',graph_data)
    for j in range(30):    
        if( abs(y[2+j*3])-31 < (1e-6)):
            print('*****')
            print(y)
            print(i)
            print('*****')
            x_ax.append(i*0.001+j*0.002)
            y1_ax.append(y[0+j*3])
            y2_ax.append(y[1+j*3])
            if len(x_ax)>100:
                del(x_ax[0])
                del(y1_ax[0])
                del(y2_ax[0])
    ax1.clear()
    ax1.plot(x_ax,y1_ax,label='Atrl_Signal')
    ax1.plot(x_ax,y2_ax,label='Vent_Signal')
    ax1.set_xlabel('Time (s)')
    ax1.set_ylabel('Amplitude (mV)')
    ax1.set_ylim(bottom=-2,top=2)
    ax1.set_title('Egram Data Visiualization')
    ax1.legend(loc='upper right')
    print('/n')
    print(y[0])
    print(y[1])

animate(1)
plt.show()
'''
#fig, ax1 = plt.subplots(constrained_layout=True)
ani = animation.FuncAnimation(fig, animate,interval=150)
plt.show()
'''

'''
    x_ax.append(i*0.002)
    y1_ax.append(y[0])
    y2_ax.append(y[1])
    x_ax.append(i*0.002)
    y1_ax.append(y[3])
    y2_ax.append(y[4])
    x_ax.append(i*0.002)
    y1_ax.append(y[6])
    y2_ax.append(y[7])
    x_ax.append(i*0.002)
    y1_ax.append(y[9])
    y2_ax.append(y[10])
    x_ax.append(i*0.002)
    y1_ax.append(y[12])
    y2_ax.append(y[13])
    x_ax.append(i*0.002)
    y1_ax.append(y[15])
    y2_ax.append(y[16])
    x_ax.append(i*0.002)
    y1_ax.append(y[18])
    y2_ax.append(y[19])
    x_ax.append(i*0.002)
    y1_ax.append(y[21])
    y2_ax.append(y[22])
    x_ax.append(i*0.002)
    y1_ax.append(y[24])
    y2_ax.append(y[25])
    x_ax.append(i*0.002)
    y1_ax.append(y[27])
    y2_ax.append(y[28])'''
            
    
    


