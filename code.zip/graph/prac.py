import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib import style
from struct import *
import serial

def close_event():
    plt.close() #timer calls this function after 3 seconds and closes the window 


for i in range(10):
    fig = plt.figure()
    plt.plot([1,2,3])
    timer = fig.canvas.new_timer(interval = 3000) #creating a timer object and setting an interval of 3000 milliseconds
    timer.add_callback(close_event)
    timer.start()
    plt.show()

